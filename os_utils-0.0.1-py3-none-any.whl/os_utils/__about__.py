# SPDX-FileCopyrightText: 2025-present LThomps <luke.a.thompson3@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
