# os_utils

[![PyPI - Version](https://img.shields.io/pypi/v/os-utils.svg)](https://pypi.org/project/os-utils)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/os-utils.svg)](https://pypi.org/project/os-utils)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install os-utils
```

## License

`os-utils` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
